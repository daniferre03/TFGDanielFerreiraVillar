﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProyectoTiendaDanielFerreira.FormsTallas
{
    public partial class FormTalla42 : Form
    {
        public FormTalla42()
        {
            InitializeComponent();
        }

        private void FormTalla42_Load(object sender, EventArgs e)
        {
            CargarPrecioZapatilla1();
        }

        private string connectionString = "server=DESKTOP-1863HN4;database=tiendaDanielFerreira; integrated security=true";

        private void CargarPrecioZapatilla1()
        {
            int zapatillaId = 3; // El ID de la zapatilla que deseas consultar

            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "SELECT precio FROM dbo.Zapatilla WHERE id = @id";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@id", zapatillaId);

                        object result = command.ExecuteScalar();

                        if (result != null)
                        {
                            decimal precio = Convert.ToDecimal(result);
                            label1.Text = $"{precio:C}";
                        }
                        else
                        {
                            label1.Text = "Zapatilla no encontrada.";
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al obtener el precio: " + ex.Message);
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            // Crea una instancia del formulario formLogin
            FormsZapatillas.FormJordan1 loginForm = new FormsZapatillas.FormJordan1();

            // Muestra el formulario de forma modal, es decir, el formulario principal espera a que se cierre el formLogin
            loginForm.ShowDialog();
        }
    }
}
