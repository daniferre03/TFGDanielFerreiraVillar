﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProyectoTiendaDanielFerreira.FormsZapatillas
{
    public partial class FormCampus : Form
    {
        public FormCampus()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // Crea una instancia del formulario formLogin
            FormGuiaTallas loginForm = new FormGuiaTallas();

            // Muestra el formulario de forma modal, es decir, el formulario principal espera a que se cierre el formLogin
            loginForm.ShowDialog();
        }

        private void FormCampus_Load(object sender, EventArgs e)
        {
            CargarTallaZapatilla1();
            CargarPrecioZapatilla1();
        }

        private string connectionString = "server=DESKTOP-1863HN4;database=tiendaDanielFerreira; integrated security=true";

        private void CargarTallaZapatilla1()
        {
            int zapatillaId = 1; // El ID de la zapatilla que deseas consultar

            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "SELECT talla FROM dbo.Zapatilla WHERE id = @id";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@id", zapatillaId);

                        object result = command.ExecuteScalar();

                        if (result != null)
                        {
                            // Convertimos el resultado a decimal y luego a entero para quitar los decimales
                            int talla = Convert.ToInt32(result);
                            label2.Text = "Talla " + talla.ToString();
                        }
                        else
                        {
                            label2.Text = "Talla no encontrada.";
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al obtener la talla: " + ex.Message);
            }
        }

        private void CargarPrecioZapatilla1()
        {
            int zapatillaId = 1; // El ID de la zapatilla que deseas consultar

            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "SELECT precio FROM dbo.Zapatilla WHERE id = @id";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@id", zapatillaId);

                        object result = command.ExecuteScalar();

                        if (result != null)
                        {
                            decimal precio = Convert.ToDecimal(result);
                            label4.Text = $"Precio {precio:C}";
                        }
                        else
                        {
                            label4.Text = "Zapatilla no encontrada.";
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al obtener el precio: " + ex.Message);
            }
        }
    }
}
