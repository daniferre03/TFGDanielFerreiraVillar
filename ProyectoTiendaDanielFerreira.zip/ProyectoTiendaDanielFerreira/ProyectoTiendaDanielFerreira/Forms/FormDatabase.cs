﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProyectoTiendaDanielFerreira.Forms
{
    public partial class FormDatabase : Form
    {
        public FormDatabase()
        {
            InitializeComponent();

        }

        private void FormDatabase_Load(object sender, EventArgs e)
        {
            // TODO: esta línea de código carga datos en la tabla 'tiendaDanielFerreiraDataSet.Marca' Puede moverla o quitarla según sea necesario.
            this.marcaTableAdapter.Fill(this.tiendaDanielFerreiraDataSet.Marca);
            // TODO: esta línea de código carga datos en la tabla 'tiendaDanielFerreiraDataSet.Zapatilla' Puede moverla o quitarla según sea necesario.
            this.zapatillaTableAdapter.Fill(this.tiendaDanielFerreiraDataSet.Zapatilla);
            

        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            //Eliminamos el registro actual
            zapatillaBindingSource.RemoveCurrent();

            //Actualizamos el DataSet con el tableAdapter
            zapatillaTableAdapter.Update(tiendaDanielFerreiraDataSet);

            //Actualizamos el DataGridView
            zapatillaTableAdapter.Fill(tiendaDanielFerreiraDataSet.Zapatilla);
        }

        private void btnInsertar_Click(object sender, EventArgs e)
        {
            DataRow fila = tiendaDanielFerreiraDataSet.Tables["Zapatilla"].NewRow();
            fila["Id"] = textBox0.Text;
            fila["Nombre"] = textBox1.Text;
            fila["Talla"] = textBox2.Text;
            fila["Precio"] = textBox3.Text;
            fila["Stock"] = textBox4.Text;
            fila["MarcaId"] = comboBox1.SelectedValue.ToString();
            fila["CategoriaId"] = textBox6.Text;
            tiendaDanielFerreiraDataSet.Tables["Zapatilla"].Rows.Add(fila);
            zapatillaTableAdapter.Update(tiendaDanielFerreiraDataSet);
            zapatillaTableAdapter.Fill(tiendaDanielFerreiraDataSet.Zapatilla);
        }

        private void btnActualizar_Click(object sender, EventArgs e)
        {
            // Verifica si hay una fila seleccionada
            if (dataGridView1.SelectedRows.Count > 0)
            {
                DataGridViewRow row = dataGridView1.SelectedRows[0];

                // Modifica los datos en la fila seleccionada
                row.Cells["idDataGridViewTextBoxColumn"].Value = textBox0.Text;
                row.Cells["nombreDataGridViewTextBoxColumn"].Value = textBox1.Text;
                row.Cells["tallaDataGridViewTextBoxColumn"].Value = textBox2.Text;
                row.Cells["precioDataGridViewTextBoxColumn"].Value = textBox3.Text;
                row.Cells["stockDataGridViewTextBoxColumn"].Value = textBox4.Text;
                row.Cells["marcaIdDataGridViewTextBoxColumn"].Value = textBox5.Text;
                row.Cells["categoriaIdDataGridViewTextBoxColumn"].Value = textBox6.Text;

                // Obtiene la fila de datos desde el BindingSource
                DataRowView rowView = (DataRowView)zapatillaBindingSource.Current;
                DataRow rows = rowView.Row;

                // Modifica los datos en la fila de datos
                rows["Id"] = textBox0.Text;
                rows["Nombre"] = textBox1.Text;
                rows["Talla"] = textBox2.Text;
                rows["Precio"] = textBox3.Text;
                rows["Stock"] = textBox4.Text;
                rows["MarcaId"] = textBox5.Text;
                rows["CategoriaId"] = textBox6.Text;

                // Guarda los cambios en el origen de datos
                zapatillaBindingSource.EndEdit();

                // Actualiza la base de datos
                zapatillaTableAdapter.Update(tiendaDanielFerreiraDataSet.Zapatilla);

                // Refresca el DataGridView
                dataGridView1.Refresh();
            }
        }



        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                // Obtiene la fila seleccionada
                DataGridViewRow selectedRow = dataGridView1.Rows[e.RowIndex];

                // Limpia los TextBox antes de asignar nuevos valores
                LimpiarTextBox();

                // Recorre todas las columnas de la fila seleccionada
                for (int i = 0; i < selectedRow.Cells.Count; i++)
                {
                    // Asigna el valor de la celda al TextBox correspondiente (asumiendo que tienes TextBox con nombres como textBox0, textBox1, textBox2, ...)
                    TextBox textBox = Controls.Find("textBox" + i, true).FirstOrDefault() as TextBox;
                    if (textBox != null)
                    {
                        textBox.Text = selectedRow.Cells[i].Value.ToString();
                    }
                }
            }
        }

        private void LimpiarTextBox()
        {
            foreach (Control control in Controls)
            {
                if (control is TextBox)
                {
                    ((TextBox)control).Text = string.Empty;
                }
            }
        }
    }
}
