﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProyectoTiendaDanielFerreira.Forms
{
    public partial class FormMarca : Form
    {
        public FormMarca()
        {
            InitializeComponent();
        }

        private void FormMarca_Load(object sender, EventArgs e)
        {
            // TODO: esta línea de código carga datos en la tabla 'tiendaDanielFerreiraDataSet1.Marca' Puede moverla o quitarla según sea necesario.
            this.marcaTableAdapter.Fill(this.tiendaDanielFerreiraDataSet1.Marca);

        }

        private void btnInsertar_Click(object sender, EventArgs e)
        {
            DataRow fila = tiendaDanielFerreiraDataSet1.Tables["Marca"].NewRow();
            fila["Id"] = textBox0.Text;
            fila["Nombre"] = textBox1.Text;
            tiendaDanielFerreiraDataSet1.Tables["Marca"].Rows.Add(fila);
            marcaTableAdapter.Update(tiendaDanielFerreiraDataSet1);
            marcaTableAdapter.Fill(tiendaDanielFerreiraDataSet1.Marca);
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            marcaBindingSource.RemoveCurrent();
            marcaTableAdapter.Update(tiendaDanielFerreiraDataSet1);
            marcaTableAdapter.Fill(tiendaDanielFerreiraDataSet1.Marca);
        }

        private void btnActualizar_Click(object sender, EventArgs e)
        {
            if(dataGridView1.SelectedRows.Count > 0)
            {
                DataGridViewRow row = dataGridView1.SelectedRows[0];

                row.Cells["idDataGridViewTextBoxColumn"].Value = textBox0.Text;
                row.Cells["nombreDataGridViewTextBoxColumn"].Value = textBox1.Text;

                DataRowView rowView = (DataRowView)marcaBindingSource.Current;
                DataRow rows = rowView.Row;

                rows["Id"] = textBox0.Text;
                rows["Nombre"] = textBox1.Text;

                marcaBindingSource.EndEdit();

                marcaTableAdapter.Update(tiendaDanielFerreiraDataSet1.Marca);

                dataGridView1.Refresh();
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                // Obtiene la fila seleccionada
                DataGridViewRow selectedRow = dataGridView1.Rows[e.RowIndex];

                // Limpia los TextBox antes de asignar nuevos valores
                LimpiarTextBox();

                // Recorre todas las columnas de la fila seleccionada
                for (int i = 0; i < selectedRow.Cells.Count; i++)
                {
                    // Asigna el valor de la celda al TextBox correspondiente (asumiendo que tienes TextBox con nombres como textBox0, textBox1, textBox2, ...)
                    TextBox textBox = Controls.Find("textBox" + i, true).FirstOrDefault() as TextBox;
                    if (textBox != null)
                    {
                        textBox.Text = selectedRow.Cells[i].Value.ToString();
                    }
                }
            }
        }

        private void LimpiarTextBox()
        {
            foreach (Control control in Controls)
            {
                if (control is TextBox)
                {
                    ((TextBox)control).Text = string.Empty;
                }
            }
        }
    }
}
