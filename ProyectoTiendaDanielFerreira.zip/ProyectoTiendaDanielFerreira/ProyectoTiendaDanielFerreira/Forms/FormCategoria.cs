﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProyectoTiendaDanielFerreira.Forms
{
    public partial class FormCategoria : Form
    {
        public FormCategoria()
        {
            InitializeComponent();
        }

        private void FormCategoria_Load(object sender, EventArgs e)
        {
            // TODO: esta línea de código carga datos en la tabla 'tiendaDanielFerreiraDataSet2.Categoria' Puede moverla o quitarla según sea necesario.
            this.categoriaTableAdapter.Fill(this.tiendaDanielFerreiraDataSet2.Categoria);
        }

        private void btnInsertar_Click(object sender, EventArgs e)
        {
            DataRow fila = tiendaDanielFerreiraDataSet2.Tables["Categoria"].NewRow();
            fila["Id"] = textBox0.Text;
            fila["Nombre"] = textBox1.Text;
            tiendaDanielFerreiraDataSet2.Tables["Categoria"].Rows.Add(fila);
            categoriaTableAdapter.Update(tiendaDanielFerreiraDataSet2);
            categoriaTableAdapter.Fill(tiendaDanielFerreiraDataSet2.Categoria);
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            categoriaBindingSource.RemoveCurrent();
            categoriaTableAdapter.Update(tiendaDanielFerreiraDataSet2);
            categoriaTableAdapter.Fill(tiendaDanielFerreiraDataSet2.Categoria);
        }

        private void btnActualizar_Click(object sender, EventArgs e)
        {
            if(dataGridView1.SelectedRows.Count > 0)
            {
                DataGridViewRow row = dataGridView1.SelectedRows[0];

                row.Cells["idDataGridViewTextBoxColumn"].Value = textBox0.Text;
                row.Cells["nombreDataGridViewTextBoxColumn"].Value = textBox1.Text;

                DataRowView rowView = (DataRowView)categoriaBindingSource.Current;
                DataRow rows = rowView.Row;

                rows["Id"] = textBox0.Text;
                rows["Nombre"] = textBox1.Text;

                categoriaBindingSource.EndEdit();
                categoriaTableAdapter.Update(tiendaDanielFerreiraDataSet2.Categoria);
                dataGridView1.Refresh();
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if(e.RowIndex >= 0)
            {
                DataGridViewRow selectedRow = dataGridView1.Rows[e.RowIndex];

                LimpiarTextBox();

                for(int i = 0; i < selectedRow.Cells.Count; i++)
                {
                    TextBox textBox = Controls.Find("textBox" + i, true).FirstOrDefault() as TextBox;
                    if(textBox != null)
                    {
                        textBox.Text = selectedRow.Cells[i].Value.ToString();
                    }
                }
            }
        }

        private void LimpiarTextBox()
        {
            foreach(Control control in Controls)
            {
                if(control is TextBox)
                {
                    ((TextBox)control).Text = string.Empty;
                }
            }
        }
    }
}
