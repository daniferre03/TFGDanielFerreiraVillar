﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProyectoTiendaDanielFerreira.Forms
{
    public partial class FormZapatillas : Form
    {
        public FormZapatillas()
        {
            InitializeComponent();
        }

        private void FormZapatillas_Load(object sender, EventArgs e)
        {
            // TODO: esta línea de código carga datos en la tabla 'tiendaDanielFerreiraDataSet3.Categoria' Puede moverla o quitarla según sea necesario.
            this.categoriaTableAdapter.Fill(this.tiendaDanielFerreiraDataSet3.Categoria);
            // TODO: esta línea de código carga datos en la tabla 'tiendaDanielFerreiraDataSet3.Marca' Puede moverla o quitarla según sea necesario.
            this.marcaTableAdapter.Fill(this.tiendaDanielFerreiraDataSet3.Marca);
            // TODO: esta línea de código carga datos en la tabla 'tiendaDanielFerreiraDataSet3.Zapatilla' Puede moverla o quitarla según sea necesario.
            this.zapatillaTableAdapter.Fill(this.tiendaDanielFerreiraDataSet3.Zapatilla);

        }

        private void btnInsertar_Click(object sender, EventArgs e)
        {
            DataRow fila = tiendaDanielFerreiraDataSet3.Tables["Zapatilla"].NewRow();
            fila["Id"] = textBox0.Text;
            fila["Nombre"] = textBox1.Text;
            fila["Talla"] = textBox2.Text;
            fila["Precio"] = textBox3.Text;
            fila["Stock"] = textBox4.Text;
            fila["MarcaId"] = comboBox0.SelectedValue.ToString();
            fila["CategoriaId"] = comboBox1.SelectedValue.ToString();
            tiendaDanielFerreiraDataSet3.Tables["Zapatilla"].Rows.Add(fila);
            zapatillaTableAdapter.Update(tiendaDanielFerreiraDataSet3);
            zapatillaTableAdapter.Fill(tiendaDanielFerreiraDataSet3.Zapatilla);
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            zapatillaBindingSource.RemoveCurrent();
            zapatillaTableAdapter.Update(tiendaDanielFerreiraDataSet3);
            zapatillaTableAdapter.Fill(tiendaDanielFerreiraDataSet3.Zapatilla);
        }

        private void btnActualizar_Click(object sender, EventArgs e)
        {
            if(dataGridView1.SelectedRows.Count > 0)
            {
                DataGridViewRow row = dataGridView1.Rows[0];

                row.Cells["idDataGridViewTextBoxColumn"].Value = textBox0.Text;
                row.Cells["nombreDataGridViewTextBoxColumn"].Value = textBox1.Text;
                row.Cells["tallaDataGridViewTextBoxColumn"].Value = textBox2.Text;
                row.Cells["precioDataGridViewTextBoxColumn"].Value = textBox3.Text;
                row.Cells["stockDataGridViewTextBoxColumn"].Value = textBox4.Text;
                row.Cells["marcaIdDataGridViewTextBoxColumn"].Value = comboBox0.SelectedValue.ToString();
                row.Cells["categoriaIdDataGridViewTextBoxColumn"].Value = comboBox1.SelectedValue.ToString();

                DataRowView rowView = (DataRowView)zapatillaBindingSource.Current;
                DataRow rows = rowView.Row;

                rows["Id"] = textBox0.Text;
                rows["Nombre"] = textBox1.Text;
                rows["Talla"] = textBox2.Text;
                rows["Precio"] = textBox3.Text;
                rows["Stock"] = textBox4.Text;
                rows["MarcaId"] = comboBox0.SelectedValue.ToString();
                rows["CategoriaId"] = comboBox1.SelectedValue.ToString();

                zapatillaBindingSource.EndEdit();

                zapatillaTableAdapter.Update(tiendaDanielFerreiraDataSet3.Zapatilla);

                dataGridView1.Refresh();
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow selectedRow = dataGridView1.Rows[e.RowIndex];

                LimpiarTextBoxYComboBox();

                for (int i = 0; i < selectedRow.Cells.Count; i++)
                {
                    TextBox textBox = Controls.Find("textBox" + i, true).FirstOrDefault() as TextBox;
                    if (textBox != null)
                    {
                        textBox.Text = selectedRow.Cells[i].Value.ToString();
                    }
                }

                comboBox0.SelectedValue = selectedRow.Cells["marcaIdDataGridViewTextBoxColumn"].Value;
                comboBox1.SelectedValue = selectedRow.Cells["categoriaIdDataGridViewTextBoxColumn"].Value;
            }
        }

        private void LimpiarTextBoxYComboBox()
        {
            foreach (Control control in Controls)
            {
                if (control is TextBox)
                {
                    ((TextBox)control).Text = string.Empty;
                }
                else if (control is ComboBox)
                {
                    ((ComboBox)control).SelectedIndex = -1;
                }
            }
        }
    }
}
