﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProyectoTiendaDanielFerreira.Forms
{
    public partial class FormEmpleados : Form
    {
        public FormEmpleados()
        {
            InitializeComponent();
        }

        private void FormEmpleados_Load(object sender, EventArgs e)
        {
            // TODO: esta línea de código carga datos en la tabla 'tiendaDanielFerreiraDataSet3.Empleado' Puede moverla o quitarla según sea necesario.
            this.empleadoTableAdapter.Fill(this.tiendaDanielFerreiraDataSet3.Empleado);

        }

        private void btnInsertar_Click(object sender, EventArgs e)
        {
            DataRow fila = tiendaDanielFerreiraDataSet3.Tables["Empleado"].NewRow();
            fila["Id"] = textBox0.Text;
            fila["Nombre"] = textBox1.Text;
            fila["Apellido"] = textBox2.Text;
            fila["Cargo"] = textBox3.Text;
            fila["Usuario"] = textBox4.Text;
            fila["Contraseña"] = textBox5.Text;
            tiendaDanielFerreiraDataSet3.Tables["Empleado"].Rows.Add(fila);
            empleadoTableAdapter.Update(tiendaDanielFerreiraDataSet3);
            empleadoTableAdapter.Fill(tiendaDanielFerreiraDataSet3.Empleado);
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            empleadoBindingSource.RemoveCurrent();
            empleadoTableAdapter.Update(tiendaDanielFerreiraDataSet3);
            empleadoTableAdapter.Fill(tiendaDanielFerreiraDataSet3.Empleado);
        }

        private void btnActualizar_Click(object sender, EventArgs e)
        {
            if(dataGridView1.SelectedRows.Count > 0)
            {
                DataGridViewRow row = dataGridView1.SelectedRows[0];

                row.Cells["idDataGridViewTextBoxColumn"].Value = textBox0.Text;
                row.Cells["nombreDataGridViewTextBoxColumn"].Value = textBox1.Text;
                row.Cells["apellidoDataGridViewTextBoxColumn"].Value = textBox2.Text;
                row.Cells["cargoDataGridViewTextBoxColumn"].Value = textBox3.Text;
                row.Cells["usuarioDataGridViewTextBoxColumn"].Value= textBox4.Text;
                row.Cells["contraseñaDataGridViewTextBoxColumn"].Value = textBox5.Text;

                DataRowView rowView = (DataRowView)empleadoBindingSource.Current;
                DataRow rows = rowView.Row;

                rows["Id"] = textBox0.Text;
                rows["Nombre"] = textBox1.Text;
                rows["Apellido"] = textBox2.Text;
                rows["Cargo"] = textBox3.Text;
                rows["Usuario"] = textBox4.Text;
                rows["Contraseña"] = textBox5.Text;

                empleadoBindingSource.EndEdit();

                empleadoTableAdapter.Update(tiendaDanielFerreiraDataSet3.Empleado);

                dataGridView1.Refresh();
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if(e.RowIndex >= 0)
            {
                DataGridViewRow selectedRow = dataGridView1.Rows[e.RowIndex];

                LimpiarTextBox();

                for(int i = 0; i < selectedRow.Cells.Count; i++)
                {
                    TextBox textbox = Controls.Find("textBox" + i, true).FirstOrDefault() as TextBox;
                    if(textbox != null)
                    {
                        textbox.Text = selectedRow.Cells[i].Value.ToString();
                    }
                }
            }
        }

        private void LimpiarTextBox()
        {
            foreach(Control control in Controls)
            {
                if(control is TextBox)
                {
                    ((TextBox)control).Text = string.Empty;
                }
            }
        }
    }
}
