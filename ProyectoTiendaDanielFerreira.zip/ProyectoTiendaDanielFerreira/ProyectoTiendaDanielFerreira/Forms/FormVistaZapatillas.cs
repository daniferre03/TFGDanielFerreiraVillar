﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProyectoTiendaDanielFerreira.Forms
{
    public partial class FormVistaZapatillas : Form
    {
        public FormVistaZapatillas()
        {
            InitializeComponent();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            // Crea una instancia del formulario formLogin
            FormsZapatillas.FormCampus loginForm = new FormsZapatillas.FormCampus();

            // Muestra el formulario de forma modal, es decir, el formulario principal espera a que se cierre el formLogin
            loginForm.ShowDialog();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            // Crea una instancia del formulario formLogin
            FormsZapatillas.FormAirForce loginForm = new FormsZapatillas.FormAirForce();

            // Muestra el formulario de forma modal, es decir, el formulario principal espera a que se cierre el formLogin
            loginForm.ShowDialog();
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            // Crea una instancia del formulario formLogin
            FormsZapatillas.FormJordan1 loginForm = new FormsZapatillas.FormJordan1();

            // Muestra el formulario de forma modal, es decir, el formulario principal espera a que se cierre el formLogin
            loginForm.ShowDialog();
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            // Crea una instancia del formulario formLogin
            FormsZapatillas.FormVelocity loginForm = new FormsZapatillas.FormVelocity();

            // Muestra el formulario de forma modal, es decir, el formulario principal espera a que se cierre el formLogin
            loginForm.ShowDialog();
        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {
            // Crea una instancia del formulario formLogin
            FormsZapatillas.FormNB550 loginForm = new FormsZapatillas.FormNB550();

            // Muestra el formulario de forma modal, es decir, el formulario principal espera a que se cierre el formLogin
            loginForm.ShowDialog();
        }

        private void pictureBox6_Click(object sender, EventArgs e)
        {
            // Crea una instancia del formulario formLogin
            FormsZapatillas.FormSlide loginForm = new FormsZapatillas.FormSlide();

            // Muestra el formulario de forma modal, es decir, el formulario principal espera a que se cierre el formLogin
            loginForm.ShowDialog();
        }

        private void zapatillaBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.zapatillaBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.tiendaDanielFerreiraDataSet3);

        }

        private void FormVistaZapatillas_Load(object sender, EventArgs e)
        {
            // TODO: esta línea de código carga datos en la tabla 'tiendaDanielFerreiraDataSet3.Zapatilla' Puede moverla o quitarla según sea necesario.
            this.zapatillaTableAdapter.Fill(this.tiendaDanielFerreiraDataSet3.Zapatilla);
            CargarPrecioZapatilla1();
            CargarPrecioZapatilla2();
            CargarPrecioZapatilla3();
            CargarPrecioZapatilla4();
            CargarPrecioZapatilla5();
            CargarPrecioZapatilla6();
        }

        private string connectionString = "server=DESKTOP-1863HN4;database=tiendaDanielFerreira; integrated security=true";

        private void CargarPrecioZapatilla1()
        {
            int zapatillaId = 1; // El ID de la zapatilla que deseas consultar

            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "SELECT precio FROM dbo.Zapatilla WHERE id = @id";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@id", zapatillaId);

                        object result = command.ExecuteScalar();

                        if (result != null)
                        {
                            decimal precio = Convert.ToDecimal(result);
                            lblPrecio.Text = $"{precio:C}";
                        }
                        else
                        {
                            lblPrecio.Text = "Zapatilla no encontrada.";
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al obtener el precio: " + ex.Message);
            }
        }

        private void CargarPrecioZapatilla2()
        {
            int zapatillaId = 2; // El ID de la zapatilla que deseas consultar

            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "SELECT precio FROM dbo.Zapatilla WHERE id = @id";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@id", zapatillaId);

                        object result = command.ExecuteScalar();

                        if (result != null)
                        {
                            decimal precio = Convert.ToDecimal(result);
                            lblPrecio2.Text = $"{precio:C}";
                        }
                        else
                        {
                            lblPrecio2.Text = "Zapatilla no encontrada.";
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al obtener el precio: " + ex.Message);
            }
        }

        private void CargarPrecioZapatilla3()
        {
            int zapatillaId = 3; // El ID de la zapatilla que deseas consultar

            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "SELECT precio FROM dbo.Zapatilla WHERE id = @id";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@id", zapatillaId);

                        object result = command.ExecuteScalar();

                        if (result != null)
                        {
                            decimal precio = Convert.ToDecimal(result);
                            lblPrecio3.Text = $"{precio:C}";
                        }
                        else
                        {
                            lblPrecio3.Text = "Zapatilla no encontrada.";
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al obtener el precio: " + ex.Message);
            }
        }

        private void CargarPrecioZapatilla4()
        {
            int zapatillaId = 4; // El ID de la zapatilla que deseas consultar

            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "SELECT precio FROM dbo.Zapatilla WHERE id = @id";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@id", zapatillaId);

                        object result = command.ExecuteScalar();

                        if (result != null)
                        {
                            decimal precio = Convert.ToDecimal(result);
                            lblPrecio4.Text = $"{precio:C}";
                        }
                        else
                        {
                            lblPrecio4.Text = "Zapatilla no encontrada.";
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al obtener el precio: " + ex.Message);
            }
        }

        private void CargarPrecioZapatilla5()
        {
            int zapatillaId = 5; // El ID de la zapatilla que deseas consultar

            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "SELECT precio FROM dbo.Zapatilla WHERE id = @id";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@id", zapatillaId);

                        object result = command.ExecuteScalar();

                        if (result != null)
                        {
                            decimal precio = Convert.ToDecimal(result);
                            lblPrecio5.Text = $"{precio:C}";
                        }
                        else
                        {
                            lblPrecio5.Text = "Zapatilla no encontrada.";
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al obtener el precio: " + ex.Message);
            }
        }

        private void CargarPrecioZapatilla6()
        {
            int zapatillaId = 6; // El ID de la zapatilla que deseas consultar

            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "SELECT precio FROM dbo.Zapatilla WHERE id = @id";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@id", zapatillaId);

                        object result = command.ExecuteScalar();

                        if (result != null)
                        {
                            decimal precio = Convert.ToDecimal(result);
                            lblPrecio6.Text = $"{precio:C}";
                        }
                        else
                        {
                            lblPrecio6.Text = "Zapatilla no encontrada.";
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al obtener el precio: " + ex.Message);
            }
        }
    }
}
