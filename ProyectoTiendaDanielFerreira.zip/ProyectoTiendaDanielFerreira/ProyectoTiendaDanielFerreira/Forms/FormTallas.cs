﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProyectoTiendaDanielFerreira.Forms
{
    public partial class FormTallas : Form
    {
        private Form formActivo;

        public FormTallas()
        {
            InitializeComponent();
        }

        private void FormTallas_Load(object sender, EventArgs e)
        {

        }

        private string connectionString = "server=DESKTOP-1863HN4;database=tiendaDanielFerreira; integrated security=true";

        private void VerificarTallaZapatilla(string talla)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "SELECT COUNT(*) FROM dbo.Zapatilla WHERE Talla = @talla";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@talla", talla);

                        int count = (int)command.ExecuteScalar();

                        if (count == 0)
                        {
                            label1.Visible = true;
                            label1.Text = "No hay zapatillas con esa talla.";
                        }
                        else
                        {
                            label1.Visible = false;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al verificar la talla: " + ex.Message);
            }
        }

        private void AbrirFormularios(Form formHijo, object btnSender)
        {
            if (formActivo != null)
            {
                formActivo.Close();
            }
            formActivo = formHijo;
            formHijo.TopLevel = false;
            formHijo.FormBorderStyle = FormBorderStyle.None;
            formHijo.Dock = DockStyle.Fill;
            this.panel1.Controls.Add(formHijo);
            this.panel1.Tag = formHijo;
            formHijo.BringToFront();
            formHijo.Show();
        }

        private void btnTalla35_Click(object sender, EventArgs e)
        {
            string talla = "35"; // Asumiendo que tienes un TextBox donde ingresas la talla
            VerificarTallaZapatilla(talla);
        }

        private void btnTalla36_Click(object sender, EventArgs e)
        {
            string talla = "36"; // Asumiendo que tienes un TextBox donde ingresas la talla
            VerificarTallaZapatilla(talla);
        }

        private void btnTalla37_Click(object sender, EventArgs e)
        {
            string talla = "37"; // Asumiendo que tienes un TextBox donde ingresas la talla
            VerificarTallaZapatilla(talla);
        }

        private void btnTalla38_Click(object sender, EventArgs e)
        {
            string talla = "38"; // Asumiendo que tienes un TextBox donde ingresas la talla
            VerificarTallaZapatilla(talla);
        }

        private void btnTalla39_Click(object sender, EventArgs e)
        {
            string talla = "39"; // Asumiendo que tienes un TextBox donde ingresas la talla
            VerificarTallaZapatilla(talla);
        }

        private void btnTalla40_Click(object sender, EventArgs e)
        {
            string talla = "40"; // Asumiendo que tienes un TextBox donde ingresas la talla
            VerificarTallaZapatilla(talla);
            AbrirFormularios(new FormsTallas.FormTalla40(), sender);
        }

        private void btnTalla41_Click(object sender, EventArgs e)
        {
            string talla = "41"; // Asumiendo que tienes un TextBox donde ingresas la talla
            VerificarTallaZapatilla(talla);
            AbrirFormularios(new FormsTallas.FormTalla41(), sender);
        }

        private void btnTalla42_Click(object sender, EventArgs e)
        {
            string talla = "42"; // Asumiendo que tienes un TextBox donde ingresas la talla
            VerificarTallaZapatilla(talla);
            AbrirFormularios(new FormsTallas.FormTalla42(), sender);
        }

        private void btnTalla43_Click(object sender, EventArgs e)
        {
            string talla = "43"; // Asumiendo que tienes un TextBox donde ingresas la talla
            VerificarTallaZapatilla(talla);
            AbrirFormularios(new FormsTallas.FormTalla43(), sender);
        }

        private void btnTalla44_Click(object sender, EventArgs e)
        {
            string talla = "44"; // Asumiendo que tienes un TextBox donde ingresas la talla
            VerificarTallaZapatilla(talla);
            AbrirFormularios(new FormsTallas.FormTalla44(), sender);
        }

        private void btnTalla45_Click(object sender, EventArgs e)
        {
            string talla = "45"; // Asumiendo que tienes un TextBox donde ingresas la talla
            VerificarTallaZapatilla(talla);
            AbrirFormularios(new FormsTallas.FormTalla45(), sender);
        }
    }
}
