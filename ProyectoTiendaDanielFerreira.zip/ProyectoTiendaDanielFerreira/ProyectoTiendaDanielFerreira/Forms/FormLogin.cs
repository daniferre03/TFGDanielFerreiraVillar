﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace ProyectoTiendaDanielFerreira.Forms
{
    public partial class FormLogin : Form
    {
        public FormLogin()
        {
            InitializeComponent();
        }

        SqlConnection conexion = new SqlConnection("server=DESKTOP-1863HN4;database=tiendaDanielFerreira; integrated security=true");
        private void FormLogin_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            conexion.Open();
            string consulta = "select * from empleado where usuario='"+textBox1.Text+"' and contraseña='"+textBox2.Text+"'";
            SqlCommand comando = new SqlCommand(consulta,conexion);
            SqlDataReader lector;
            lector = comando.ExecuteReader();

            if (lector.HasRows == true)
            {

                FormAccesoLogin loginForm = new FormAccesoLogin();

                // Muestra el formulario de forma modal, es decir, el formulario principal espera a que se cierre el formLogin
                loginForm.ShowDialog();
            }
            else
            {
                MessageBox.Show("Usuario o Contraseña invalidos");
            }
            conexion.Close();
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if(checkBox1.Checked == true)
            {
                textBox2.UseSystemPasswordChar = false;
            }
            else
            {
                textBox2.UseSystemPasswordChar = true;
            }
        }
    }
}
