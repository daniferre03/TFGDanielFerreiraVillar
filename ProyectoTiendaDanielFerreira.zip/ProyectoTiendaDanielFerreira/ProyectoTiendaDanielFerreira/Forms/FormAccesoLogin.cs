﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProyectoTiendaDanielFerreira.Forms
{
    public partial class FormAccesoLogin : Form
    {
        public FormAccesoLogin()
        {
            InitializeComponent();
        }

        private Form formActivo;

        private void AbrirFormularios2(Form formHijo, object btnSender)
        {
            if (formActivo != null)
            {
                formActivo.Close();
            }
            formActivo = formHijo;
            formHijo.TopLevel = false;
            formHijo.FormBorderStyle = FormBorderStyle.None;
            formHijo.Dock = DockStyle.Fill;
            this.panel2.Controls.Add(formHijo);
            this.panel2.Tag = formHijo;
            formHijo.BringToFront();
            formHijo.Show();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            AbrirFormularios2(new Forms.FormZapatillas(), sender);
        }

        private void button6_Click(object sender, EventArgs e)
        {
            AbrirFormularios2(new Forms.FormEmpleados(), sender);
        }

        private void button7_Click(object sender, EventArgs e)
        {
            AbrirFormularios2(new Forms.FormMarca(), sender);
        }

        private void button8_Click(object sender, EventArgs e)
        {
            AbrirFormularios2(new Forms.FormCategoria(), sender);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (formActivo != null)
            {
                formActivo.Close();
                Reset();
            }
        }

        private void Reset()
        {

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            label1.Text = DateTime.Now.ToLongTimeString();
            label2.Text = DateTime.Now.ToLongDateString();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void FormAccesoLogin_Load(object sender, EventArgs e)
        {
            this.timer1.Enabled = true;
        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
