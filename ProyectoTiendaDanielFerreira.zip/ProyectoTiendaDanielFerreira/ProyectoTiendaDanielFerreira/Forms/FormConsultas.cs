﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProyectoTiendaDanielFerreira.Forms
{
    public partial class FormConsultas : Form
    {
        public FormConsultas()
        {
            InitializeComponent();
        }

        /// <summary>The cadena conexion</summary>
        string cadenaConexion = "Data Source = C06PC27\\SQLEXPRESS;Initial Catalog = tiendaDanielFerreira; Integrated Security = True";
        SqlConnection conexion = new SqlConnection();
        SqlCommand comando = new SqlCommand();

        private void FormConsultas_Load(object sender, EventArgs e)
        {
            // TODO: esta línea de código carga datos en la tabla 'tiendaDanielFerreiraDataSet.Zapatilla' Puede moverla o quitarla según sea necesario.
            this.zapatillaTableAdapter.Fill(this.tiendaDanielFerreiraDataSet.Zapatilla);
            // TODO: esta línea de código carga datos en la tabla 'tiendaDanielFerreiraDataSet.Ventas' Puede moverla o quitarla según sea necesario.
            this.ventasTableAdapter.Fill(this.tiendaDanielFerreiraDataSet.Ventas);

        }

        /// <summary>Handles the Click event of the button1 control.</summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="EventArgs" /> instance containing the event data.</param>
        private void button1_Click(object sender, EventArgs e)
        {
            conexion = new SqlConnection(cadenaConexion);

            

            comando.CommandText = "Select * from Zapatilla where precio>100";

            comando.Connection = conexion;

            conexion.Open();

            SqlDataReader resultado = comando.ExecuteReader();

            while(resultado.Read())
            {
                dataGridView2.Visible = true;
            }
            conexion.Close();
        }

        /// <summary>Handles the Click event of the fillByToolStripButton control.</summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="EventArgs" /> instance containing the event data.</param>
        private void fillByToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.zapatillaTableAdapter.FillBy(this.tiendaDanielFerreiraDataSet.Zapatilla);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }

        /// <summary>Handles the Click event of the fillBy1ToolStripButton control.</summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="EventArgs" /> instance containing the event data.</param>
        private void fillBy1ToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.zapatillaTableAdapter.FillBy1(this.tiendaDanielFerreiraDataSet.Zapatilla);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }

        /// <summary>Handles the Click event of the button2 control.</summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="EventArgs" /> instance containing the event data.</param>
        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                // Aquí asumo que tienes un TableAdapter llamado 'tuTableAdapter' 
                // y el método 'Fill1' que quieres activar.
                zapatillaTableAdapter.FillBy1(tiendaDanielFerreiraDataSet.Zapatilla); // Reemplaza con los nombres reales.

                // Si deseas realizar alguna acción adicional después de llenar los datos, agrégala aquí.
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al llenar datos: " + ex.Message);
            }
        }
    }
}
