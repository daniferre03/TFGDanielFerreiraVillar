﻿namespace ProyectoTiendaDanielFerreira.Forms
{
    partial class FormTallas
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnTalla35 = new System.Windows.Forms.Button();
            this.btnTalla36 = new System.Windows.Forms.Button();
            this.btnTalla37 = new System.Windows.Forms.Button();
            this.btnTalla38 = new System.Windows.Forms.Button();
            this.btnTalla39 = new System.Windows.Forms.Button();
            this.btnTalla40 = new System.Windows.Forms.Button();
            this.btnTalla41 = new System.Windows.Forms.Button();
            this.btnTalla42 = new System.Windows.Forms.Button();
            this.btnTalla43 = new System.Windows.Forms.Button();
            this.btnTalla44 = new System.Windows.Forms.Button();
            this.btnTalla45 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnTalla35
            // 
            this.btnTalla35.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.btnTalla35.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTalla35.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTalla35.ForeColor = System.Drawing.Color.Black;
            this.btnTalla35.Location = new System.Drawing.Point(43, 12);
            this.btnTalla35.Name = "btnTalla35";
            this.btnTalla35.Size = new System.Drawing.Size(62, 40);
            this.btnTalla35.TabIndex = 0;
            this.btnTalla35.Text = "Talla 35";
            this.btnTalla35.UseVisualStyleBackColor = false;
            this.btnTalla35.Click += new System.EventHandler(this.btnTalla35_Click);
            // 
            // btnTalla36
            // 
            this.btnTalla36.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.btnTalla36.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTalla36.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTalla36.Location = new System.Drawing.Point(120, 12);
            this.btnTalla36.Name = "btnTalla36";
            this.btnTalla36.Size = new System.Drawing.Size(62, 40);
            this.btnTalla36.TabIndex = 1;
            this.btnTalla36.Text = "Talla 36";
            this.btnTalla36.UseVisualStyleBackColor = false;
            this.btnTalla36.Click += new System.EventHandler(this.btnTalla36_Click);
            // 
            // btnTalla37
            // 
            this.btnTalla37.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.btnTalla37.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTalla37.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTalla37.Location = new System.Drawing.Point(199, 12);
            this.btnTalla37.Name = "btnTalla37";
            this.btnTalla37.Size = new System.Drawing.Size(62, 40);
            this.btnTalla37.TabIndex = 2;
            this.btnTalla37.Text = "Talla 37";
            this.btnTalla37.UseVisualStyleBackColor = false;
            this.btnTalla37.Click += new System.EventHandler(this.btnTalla37_Click);
            // 
            // btnTalla38
            // 
            this.btnTalla38.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.btnTalla38.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTalla38.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTalla38.Location = new System.Drawing.Point(279, 12);
            this.btnTalla38.Name = "btnTalla38";
            this.btnTalla38.Size = new System.Drawing.Size(62, 40);
            this.btnTalla38.TabIndex = 3;
            this.btnTalla38.Text = "Talla 38";
            this.btnTalla38.UseVisualStyleBackColor = false;
            this.btnTalla38.Click += new System.EventHandler(this.btnTalla38_Click);
            // 
            // btnTalla39
            // 
            this.btnTalla39.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.btnTalla39.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTalla39.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTalla39.Location = new System.Drawing.Point(357, 12);
            this.btnTalla39.Name = "btnTalla39";
            this.btnTalla39.Size = new System.Drawing.Size(62, 40);
            this.btnTalla39.TabIndex = 4;
            this.btnTalla39.Text = "Talla 39";
            this.btnTalla39.UseVisualStyleBackColor = false;
            this.btnTalla39.Click += new System.EventHandler(this.btnTalla39_Click);
            // 
            // btnTalla40
            // 
            this.btnTalla40.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.btnTalla40.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTalla40.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTalla40.Location = new System.Drawing.Point(436, 12);
            this.btnTalla40.Name = "btnTalla40";
            this.btnTalla40.Size = new System.Drawing.Size(62, 40);
            this.btnTalla40.TabIndex = 5;
            this.btnTalla40.Text = "Talla 40";
            this.btnTalla40.UseVisualStyleBackColor = false;
            this.btnTalla40.Click += new System.EventHandler(this.btnTalla40_Click);
            // 
            // btnTalla41
            // 
            this.btnTalla41.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.btnTalla41.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTalla41.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTalla41.Location = new System.Drawing.Point(519, 12);
            this.btnTalla41.Name = "btnTalla41";
            this.btnTalla41.Size = new System.Drawing.Size(62, 40);
            this.btnTalla41.TabIndex = 6;
            this.btnTalla41.Text = "Talla 41";
            this.btnTalla41.UseVisualStyleBackColor = false;
            this.btnTalla41.Click += new System.EventHandler(this.btnTalla41_Click);
            // 
            // btnTalla42
            // 
            this.btnTalla42.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.btnTalla42.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTalla42.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTalla42.Location = new System.Drawing.Point(599, 12);
            this.btnTalla42.Name = "btnTalla42";
            this.btnTalla42.Size = new System.Drawing.Size(62, 40);
            this.btnTalla42.TabIndex = 7;
            this.btnTalla42.Text = "Talla 42";
            this.btnTalla42.UseVisualStyleBackColor = false;
            this.btnTalla42.Click += new System.EventHandler(this.btnTalla42_Click);
            // 
            // btnTalla43
            // 
            this.btnTalla43.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.btnTalla43.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTalla43.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTalla43.Location = new System.Drawing.Point(679, 12);
            this.btnTalla43.Name = "btnTalla43";
            this.btnTalla43.Size = new System.Drawing.Size(62, 40);
            this.btnTalla43.TabIndex = 8;
            this.btnTalla43.Text = "Talla 43";
            this.btnTalla43.UseVisualStyleBackColor = false;
            this.btnTalla43.Click += new System.EventHandler(this.btnTalla43_Click);
            // 
            // btnTalla44
            // 
            this.btnTalla44.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.btnTalla44.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTalla44.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTalla44.Location = new System.Drawing.Point(759, 12);
            this.btnTalla44.Name = "btnTalla44";
            this.btnTalla44.Size = new System.Drawing.Size(62, 40);
            this.btnTalla44.TabIndex = 9;
            this.btnTalla44.Text = "Talla 44";
            this.btnTalla44.UseVisualStyleBackColor = false;
            this.btnTalla44.Click += new System.EventHandler(this.btnTalla44_Click);
            // 
            // btnTalla45
            // 
            this.btnTalla45.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.btnTalla45.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTalla45.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTalla45.Location = new System.Drawing.Point(837, 12);
            this.btnTalla45.Name = "btnTalla45";
            this.btnTalla45.Size = new System.Drawing.Size(62, 40);
            this.btnTalla45.TabIndex = 10;
            this.btnTalla45.Text = "Talla 45";
            this.btnTalla45.UseVisualStyleBackColor = false;
            this.btnTalla45.Click += new System.EventHandler(this.btnTalla45_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(382, 115);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(0, 33);
            this.label1.TabIndex = 12;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(3, 103);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(921, 345);
            this.panel1.TabIndex = 13;
            // 
            // FormTallas
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(924, 450);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.btnTalla45);
            this.Controls.Add(this.btnTalla44);
            this.Controls.Add(this.btnTalla43);
            this.Controls.Add(this.btnTalla42);
            this.Controls.Add(this.btnTalla41);
            this.Controls.Add(this.btnTalla40);
            this.Controls.Add(this.btnTalla39);
            this.Controls.Add(this.btnTalla38);
            this.Controls.Add(this.btnTalla37);
            this.Controls.Add(this.btnTalla36);
            this.Controls.Add(this.btnTalla35);
            this.Name = "FormTallas";
            this.Text = "FormTallas";
            this.Load += new System.EventHandler(this.FormTallas_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnTalla35;
        private System.Windows.Forms.Button btnTalla36;
        private System.Windows.Forms.Button btnTalla37;
        private System.Windows.Forms.Button btnTalla38;
        private System.Windows.Forms.Button btnTalla39;
        private System.Windows.Forms.Button btnTalla40;
        private System.Windows.Forms.Button btnTalla41;
        private System.Windows.Forms.Button btnTalla42;
        private System.Windows.Forms.Button btnTalla43;
        private System.Windows.Forms.Button btnTalla44;
        private System.Windows.Forms.Button btnTalla45;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel1;
    }
}