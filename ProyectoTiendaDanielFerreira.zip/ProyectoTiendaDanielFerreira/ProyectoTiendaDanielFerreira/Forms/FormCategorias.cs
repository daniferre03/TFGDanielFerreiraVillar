﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProyectoTiendaDanielFerreira.Forms
{
    public partial class FormCategorias : Form
    {
        private Form formActivo;

        public FormCategorias()
        {
            InitializeComponent();
        }

        private void FormCategorias_Load(object sender, EventArgs e)
        {

        }

        private void AbrirFormularios(Form formHijo, object btnSender)
        {
            if (formActivo != null)
            {
                formActivo.Close();
            }
            formActivo = formHijo;
            formHijo.TopLevel = false;
            formHijo.FormBorderStyle = FormBorderStyle.None;
            formHijo.Dock = DockStyle.Fill;
            this.panel1.Controls.Add(formHijo);
            this.panel1.Tag = formHijo;
            formHijo.BringToFront();
            formHijo.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            AbrirFormularios(new FormsCategorias.FormRunning(), sender);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            AbrirFormularios(new FormsCategorias.FormSkate(), sender);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            AbrirFormularios(new FormsCategorias.FormChunky(), sender);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            AbrirFormularios(new FormsCategorias.FormModa(), sender);
        }

        private void button5_Click(object sender, EventArgs e)
        {
            AbrirFormularios(new FormsCategorias.FormChanclas(), sender);
        }


    }
}
