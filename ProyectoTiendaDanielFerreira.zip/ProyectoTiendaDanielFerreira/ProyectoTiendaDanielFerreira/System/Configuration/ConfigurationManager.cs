﻿namespace System.Configuration
{
    internal class ConfigurationManager
    {
        internal static object ConnectionStrings;
    }
}