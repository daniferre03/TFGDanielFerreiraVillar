﻿using ProyectoTiendaDanielFerreira.Forms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProyectoTiendaDanielFerreira
{
    public partial class FormMenu : Form
    {
        private Form formActivo;
        
        public FormMenu()
        {
            InitializeComponent();
        }

        private void AbrirFormularios(Form formHijo, object btnSender)
        {
            if (formActivo != null)
            {
                formActivo.Close();
            }
            formActivo = formHijo;
            formHijo.TopLevel = false;
            formHijo.FormBorderStyle = FormBorderStyle.None;
            formHijo.Dock = DockStyle.Fill;
            this.panel2.Controls.Add(formHijo);
            this.panel2.Tag = formHijo;
            formHijo.BringToFront();
            formHijo.Show();
        }

        private void FormMenu_Load(object sender, EventArgs e)
        {
            // TODO: esta línea de código carga datos en la tabla 'tiendaDanielFerreiraDataSet.Zapatilla' Puede moverla o quitarla según sea necesario.
            //this.zapatillaTableAdapter.Fill(this.tiendaDanielFerreiraDataSet.Zapatilla);
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            AbrirFormularios(new Forms.FormVistaZapatillas(),sender);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (formActivo != null)
            {
                formActivo.Close();
                Reset();
            }
        }

        private void Reset()
        {
            
        }

        private void horaFecha_Tick(object sender, EventArgs e)
        {
            label1.Text = DateTime.Now.ToLongTimeString();
            label2.Text = DateTime.Now.ToLongDateString();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            AbrirFormularios(new Forms.FormTallas(), sender);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            AbrirFormularios(new Forms.FormCategorias(), sender);
        }

        private void button5_Click(object sender, EventArgs e)
        {
            /*// Especifica la ruta completa del archivo CHM
            string rutaArchivoCHM = @"G:\2DAM2Evaluacion\DesarrolloInterfaces\Crear documentación chm\Title of this help project.chm";

            // Intenta abrir el archivo CHM
            try
            {
                System.Diagnostics.Process.Start(rutaArchivoCHM);
            }
            catch (Exception ex)
            {
                // Maneja cualquier excepción que pueda ocurrir al intentar abrir el archivo
                MessageBox.Show("Error al abrir el archivo CHM: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }*/

            AbrirFormularios(new Forms.FormAyuda(), sender);
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void button6_Click(object sender, EventArgs e)
        {
            // Crea una instancia del formulario formLogin
            FormLogin loginForm = new FormLogin();

            // Muestra el formulario de forma modal, es decir, el formulario principal espera a que se cierre el formLogin
            loginForm.ShowDialog();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnCesta_Click(object sender, EventArgs e)
        {
            AbrirFormularios(new Forms.FormCesta(), sender);
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
